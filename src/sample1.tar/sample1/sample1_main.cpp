extern "C"{
#include "sample1.h"
}
#include "gtest/gtest.h"

#if 0
namespace {

  // テスト対象となるクラス Sample1 のためのフィクスチャ
  class Sample1Fixture : public ::testing::Test {
  protected:
    // 以降の関数で中身のないものは自由に削除できます．
    //

    Sample1Fixture() {
      // テスト毎に実行される set-up をここに書きます．
    }

    virtual ~Sample1Fixture() {
      // テスト毎に実行される，例外を投げない clean-up をここに書きます．
    }

    // コンストラクタとデストラクタでは不十分な場合．
    // 以下のメソッドを定義することができます：

    virtual void SetUp() {
      // このコードは，コンストラクタの直後（各テストの直前）
      // に呼び出されます．
    }

    virtual void TearDown() {
      // このコードは，各テストの直後（デストラクタの直前）
      // に呼び出されます．
    }

    // ここで宣言されるオブジェクトは，テストケース内の全てのテストで利用できます．
  };

  // // Abc を行う Foo::Bar() メソッドをテストします．
  // TEST_F(Sample1Fixture, MethodBarDoesAbc) {
  //   const string input_filepath = "this/package/testdata/myinputfile.dat";
  //   const string output_filepath = "this/package/testdata/myoutputfile.dat";
  //   Foo f;
  //   EXPECT_EQ(0, f.Bar(input_filepath, output_filepath));
  // }

  // // Xyz を行う Foo をテストします．
  // TEST_F(Sample1Fixture, DoesXyz) {
  //   // Foo の Xyz を検査
  // }

}  // namespace
#endif


int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
